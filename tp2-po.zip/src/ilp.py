from lp import LinearProgramming


class IntLinearProgramming(LinearProgramming):
    def __init__(self):
        LinearProgramming.__init__(self)